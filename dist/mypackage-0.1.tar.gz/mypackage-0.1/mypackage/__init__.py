from .import myModule
